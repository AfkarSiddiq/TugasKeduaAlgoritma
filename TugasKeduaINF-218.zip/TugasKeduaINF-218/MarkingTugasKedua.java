class MarkingTugasKedua{
   public static void main(String args []){
      Invoker in = new Invoker();
      in.ex("Penilaian");
   }
}